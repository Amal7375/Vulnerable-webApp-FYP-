<?php
session_start();
if (!isset($_SESSION['isAdmin']) || !$_SESSION['isAdmin']) {
    header("location: signin.php?error=noLogin");
    exit();
}

include_once './dbhConnect.php';

// Handle file inclusion vulnerability
$page = isset($_GET['page']) ? $_GET['page'] : null;

// Secure action handlers
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['addMovie'])) {
        $title = $_POST['title'];
        $genre = $_POST['genre'];
        $director = $_POST['director'];
        $cast = $_POST['cast'];
        $synopsis = $_POST['synopsis'];
        $picture = $_POST['picture'];
        $query = "INSERT INTO movies (movieTitle, movieGenre, director, cast, synopsis, picture) 
                  VALUES ('$title', '$genre', '$director', '$cast', '$synopsis', '$picture')";
        mysqli_query($link, $query);
    } elseif (isset($_POST['deleteUser'])) {
        $userId = $_POST['userId'];
        $query = "DELETE FROM users WHERE userId = '$userId'";
        if (mysqli_query($link, $query)) {
            $message = "User deleted successfully!";
        } else {
            $message = "Failed to delete user. Please try again.";
        }
    } elseif (isset($_POST['deleteReview'])) {
        $reviewId = $_POST['reviewId'];
        $query = "DELETE FROM reviews WHERE reviewId = '$reviewId'";
        if (mysqli_query($link, $query)) {
            $message = "Review deleted successfully!";
        } else {
            $message = "Failed to delete review. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body class="bg-dark text-light">
    <!-- Include Header -->
    <?php include './header.php'; ?>

    <div class="container mt-5">
        <h1 class="text-center text-white mb-4">Admin Dashboard</h1>

        <?php if (isset($message)) { ?>
            <div class="alert alert-info text-center"><?php echo $message; ?></div>
        <?php } ?>

        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3">
                <div class="card bg-dark border-light mb-4">
                    <div class="card-header text-white text-center">
                        <h4>Admin Actions</h4>
                    </div>
                    <div class="list-group list-group-flush">
                        <a href="?page=addMovie" class="list-group-item list-group-item-action bg-dark text-white">Add Movie</a>
                        <a href="?page=deleteUser" class="list-group-item list-group-item-action bg-dark text-white">Delete User</a>
                        <a href="?page=deleteReview" class="list-group-item list-group-item-action bg-dark text-white">Delete Reviews</a>
                        <a href="signout.php" class="list-group-item list-group-item-action bg-dark text-danger">Sign Out</a>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9">
                <div class="card bg-dark border-light">
                    <div class="card-body">
                        <?php
                        // File Inclusion Vulnerability
                        if ($page) {
                            include($page . ".php");
                        } else {
                            echo "<h5 class='text-center text-white'>Welcome to the Admin Dashboard! Select an action from the menu.</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include Footer -->
    <?php include './footer.php'; ?>
</body>
</html>
