<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<?php
session_start();
include_once './dbhConnect.php';


if (isset($_SESSION["userId"])) {

    $userId = $_SESSION['userId'];
    $movieId = $_SESSION['movieId'];

    if (!$link) {
        echo 'Connection error';
        exit();
    } else {
        $query = "DELETE FROM reviews WHERE movieId = '$movieId' AND userId = '$userId'";

        $result = mysqli_query($link, $query) or die(mysqli_error($link));

        header('location:./movieInfo.php?id=' . $movieId . '&deleted');
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
