<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
// Including header
include_once './header.php';

// Handling remember me functionality
if (isset($_COOKIE["rememberMe"]) && ($_COOKIE["rememberMe"] !== "0")) {
    $username = $_COOKIE["rememberMe"];
} else {
    $username = "";
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Login Page</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    </head>
    
    <body class="bg-dark">
        <section class="bg-dark">
            <div class="row bg-dark" id="signIn">
                <div class="mask d-flex align-items-center h-100 gradient-custom-3">
                    <div class="container h-100">
                        <div class="row d-flex justify-content-center align-items-center h-100">
                            <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                                <div class="card mt-3 mb-5" style="border-radius: 15px;">
                                    <div class="card-body p-5">
                                        <h2 class="text-uppercase text-center mb-5">Login</h2>
                                        <?php
                                        // Display different messages based on URL parameters
                                        if (isset($_GET["rating"])) {
                                            echo '<div class="alert alert-danger"><b>Login to write a review.</b></div>';
                                        } else if (isset($_GET['error'])) {
                                            $val = $_GET['error'];
                                            if ($val == "wrongCredentials") {
                                                echo '<div class="alert alert-danger"><b>Username or password is wrong.</b></div>';
                                            } elseif ($val == "noLogin") {
                                                echo '<div class="alert alert-danger"><b>Need to log in first.</b></div>';
                                            }
                                        } else if (isset($_GET["message"]) && $_GET["message"] === "Success") {
                                            echo '<div class="alert alert-success"><b>Account registration successful.</b></div>';
                                        }
                                        ?>
                                        <!-- Login form -->
                                        <form action="doSignIn.php" method="post" class="needs-validation">
                                            <!-- Username -->
                                            <div class="form-floating was-validated">
                                                <input type="text" class="rounded-pill form-control form-control-lg" name="username" placeholder=" " value='<?php echo $username; ?>' required />
                                                <label class="ps-4" for="username">Username</label>
                                            </div><br>
                                            <!-- Password -->
                                            <div class="form-floating was-validated">
                                                <input type="password" class="form-control form-control-lg rounded-pill" name="password" placeholder=" " value='' required />
                                                <label class="ps-4" for="password">Password</label>
                                            </div><br>
                                            <!-- Remember Me checkbox -->
                                            <div class="form-check d-flex m-1">
                                                <input class="form-check-input me-2" type="checkbox" value="on" name="rememberMe" id="loginCheckbox" />
                                                <label class="form-check-label" for="loginCheckbox">Remember me</label>
                                            </div>
                                            <!-- Login Button -->
                                            <div class="d-flex justify-content-center">
                                                <button type="submit" class="btn btn-success btn-block btn-lg gradient-custom-4 text-body">Login</button>
                                            </div>
                                            <!-- Registration Link -->
                                            <p class="text-center text-dark mt-5 mb-0">Not a member yet? <a href="register.php" class="fw-bold text-body"><u>Register</u></a> now!</p>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php
        // Including footer
        include_once './footer.php';
        ?>
    </body>
</html>
