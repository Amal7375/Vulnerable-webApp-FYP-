<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
session_start();


if (isset($_SESSION['userId'])) {

    include_once './header.php';
    ?>
    <html>
        <head>
            <meta charset="UTF-8">
            <title></title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        </head>
        <body class="bg-dark">

            
            <section class="vh-100 my-5 py-5 bg-dark" style="background-color: #f4f5f7;">
                <div class="container">
                    <div class="row d-flex justify-content-center align-items-center h-100">
                        <div class="col col-lg-6 mb-4 mb-lg-0">
                            <div class="card mb-3" style="border-radius: .5rem;">
                                <div class="container">
                                    <?php
                                    // Display error message if error is set in the URL
                                    if (isset($_GET["error"])) {
                                        echo '<div class="alert alert-danger"><b>Try Again</b></div>';
                                    }
                                    // Display success message if Success is set in the URL
                                    else if (isset($_GET['Success'])) {
                                        echo '<div class="alert alert-success"><b>User profile updated.</b></div>';
                                    }
                                    ?>
                                    <div class="row g-0">
                                        <!-- User Profile Information -->
                                        <div class="col-md-4 d-flex flex-column align-items-center mt-5">
                                            <img src="images/avatar.webp" height="100" class="rounded-circle" />
                                            <h4 class="mt-2"><b><i><?php echo $_SESSION['username'] ?></i></b></h4>
                                            <form method="post" action="doDeleteUser.php">
                                                <button type="submit" name="submit" value="submit" class="btn btn-sm btn-danger">Delete Account</button>
                                            </form>
                                        </div>
                                        <!-- Editable Profile Fields -->
                                        <div class="col-md-8 gradient-custom text-center text-dark my-5">
                                            <form method="post" action="doUpdateUser.php">
                                                <!-- Editable name field -->
                                                <input type="text" name="name" value="<?php echo $_SESSION['name'] ?>">
                                                <br><br>
                                                <!-- Editable password field -->
                                                <input type="password" name="password" value="R@nd0mT3sct">
                                                <br><br>
                                                <!-- Editable email field -->
                                                <input type="text" name="email" value="<?php echo $_SESSION['email'] ?>">
                                                <br><br>
                                                <!-- Editable date of birth field -->
                                                <input type="date" name="dob" style="width: 185px" value="<?php echo $_SESSION['dob'] ?>">
                                                <br><br>
                                                <!-- Save Changes button -->
                                                <button type="submit" name="submit" value="submit" class="btn btn-success">Save Changes</button>
                                            </form>
                                            <!-- End of editable fields -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <?php
            // You can update other fields in a similar way
        } else {
            header("location:/home.php");
        }
        ?>
    </body>
</html>
