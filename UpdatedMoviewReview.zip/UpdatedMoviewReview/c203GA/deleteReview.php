<?php
include_once './dbhConnect.php';

// Fetch all reviews along with associated user and movie details
$query = "
    SELECT r.reviewId, r.review, r.rating, r.datePosted, u.username, m.movieTitle
    FROM reviews r
    JOIN users u ON r.userId = u.userId
    JOIN movies m ON r.movieId = m.movieId
";
$result = mysqli_query($link, $query);
?>

<h3>Delete Review</h3>
<div class="table-responsive">
    <table class="table table-dark table-striped">
        <thead>
            <tr>
                <th>Review ID</th>
                <th>Username</th>
                <th>Movie Title</th>
                <th>Review</th>
                <th>Rating</th>
                <th>Date Posted</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                        <td>{$row['reviewId']}</td>
                        <td>{$row['username']}</td>
                        <td>{$row['movieTitle']}</td>
                        <td>{$row['review']}</td>
                        <td>{$row['rating']}</td>
                        <td>{$row['datePosted']}</td>
                        <td>
                            <form method='post' action='admin.php'>
                                <input type='hidden' name='reviewId' value='{$row['reviewId']}'>
                                <button type='submit' name='deleteReview' class='btn btn-danger'>Delete</button>
                            </form>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='7' class='text-center'>No reviews found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
