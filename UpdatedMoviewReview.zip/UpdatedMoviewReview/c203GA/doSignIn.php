<?php
include_once './dbhConnect.php';
session_start();

$Uname = $_POST['username'];
$Pwd = $_POST['password'];

// Check if the user is an admin
$adminQuery = "SELECT * FROM admin WHERE BINARY username = '$Uname' AND password = '$Pwd'";
$adminResult = mysqli_query($link, $adminQuery);

if (mysqli_num_rows($adminResult) > 0) {
    // Admin login successful
    $admin = mysqli_fetch_array($adminResult);
    $_SESSION['isAdmin'] = true;
    $_SESSION['adminId'] = $admin['adminId'];
    $_SESSION['username'] = $admin['username'];
    header("location: admin.php");
    exit();
}

// Check if the user is a regular user
$userQuery = "SELECT * FROM users WHERE BINARY username = '$Uname' AND password = '$Pwd'";
$userResult = mysqli_query($link, $userQuery);

if (mysqli_num_rows($userResult) > 0) {
    // User login successful
    $user = mysqli_fetch_array($userResult);
    $_SESSION['isAdmin'] = false;
    $_SESSION['userId'] = $user['userId'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['name'] = $user['name'];
    $_SESSION['dob'] = $user['dob'];
    $_SESSION['email'] = $user['email'];

    if (isset($_POST['rememberMe'])) {
        setcookie("rememberMe", $_SESSION['username'], time() + 60 * 60 * 24 * 14); // Remember for 14 days
    } else {
        setcookie("rememberMe", "", time() - 3600); // Clear cookie
    }

    header("location: home.php?success");
    exit();
} else {
    // Invalid credentials
    header("location: signin.php?error=wrongCredentials");
    exit();
}
