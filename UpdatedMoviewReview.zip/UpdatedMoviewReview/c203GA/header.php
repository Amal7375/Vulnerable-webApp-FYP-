<?php
if (isset($_SESSION['isAdmin']) && $_SESSION['isAdmin']) {
    // Admin-specific header
    ?>
    <header>
        <div class="row">
            <nav class="navbar navbar-expand-sm bg-dark" style="height: 90px">
                <div class="container-fluid">
                    <!-- Admin Title -->
                    <div class="col-lg-3 mt-2 ps-4">
                        <a class="navbar-brand text-white fs-3" href="admin.php">Admin Dashboard</a>
                    </div>

                    <!-- Sign Out Option for Admin -->
                    <div class="collapse navbar-collapse col-lg-9 col-md-4 justify-content-end mt-3" id="navbarSupportedContent">
                        <a class="navbar-brand text-light fw-bold px-3 fs-4" href="signout.php"><u>Sign Out</u></a>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <?php
} else {
    // Regular user header
    if (isset($_SESSION['userId'])) {
        ?>
        <header>
            <div class="row">
                <nav class="navbar navbar-expand-sm bg-dark" style="height: 90px">
                    <div class="container-fluid">
                        <!-- Site Title -->
                        <div class="col-lg-3 mt-2 ps-4">
                            <a class="navbar-brand text-white fs-3" href="home.php">Movie Review</a>
                            <a class="navbar-brand text-white" href="home.php#moviesList">Movies</a>
                        </div>

                        <!-- Toggler Button -->
                        <button class="navbar-toggler btn-outline-light" type="button" style="border-color: white; background-color: black" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" 
                                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            More
                        </button>

                        <!-- Search Bar and Avatar - Collapsible -->
                        <div class="collapse navbar-collapse col-lg-9 col-md-4 col-3 justify-content-end flex-column flex-md-row" id="navbarSupportedContent">
                            <form class="d-flex" method="GET" action="search.php">
                                <input class="form-control me-2 mt-1" type="search" placeholder="Search" aria-label="Search" name="q">
                                <button class="btn btn-light bg-transparent mt-1" style="color: white" type="submit">
                                    Search
                                </button>
                            </form>
                            <!-- Avatar -->
                            <div class="dropdown ps-4">
                                <a
                                    class="dropdown-toggle d-flex align-items-center hidden-arrow"
                                    href="#"
                                    id="navbarDropdownMenuAvatar"
                                    role="button"
                                    data-bs-toggle="dropdown"
                                    aria-expanded="false"
                                    >
                                    <img
                                        src="images/avatar.webp"
                                        class="rounded-circle"
                                        height="50"
                                        alt="Black and White Portrait of a Man"
                                        loading="lazy"
                                        />
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuAvatar">
                                    <li>
                                        <a class="dropdown-item" href="userProfile.php">My profile</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="signout.php">Logout</a>
                                    </li>
                                </ul>
                            </div><br>
                            <?php
                            if (isset($_GET["success"])) {
                                echo '<div class="alert alert-success"><b>Hi ' . $_SESSION['username'] . '</b></div>';
                            }
                            ?>
                        </div>
                    </div>
                </nav>
            </div>
        </header>
        <?php
    } else {
        ?>
        <header>
            <div class="row">
                <nav class="navbar navbar-expand-sm bg-dark" style="height: 90px">
                    <div class="container-fluid">
                        <!-- Site Title -->
                        <div class="col-lg-3 mt-2 ps-4">
                            <a class="navbar-brand text-white fs-3" href="home.php">Movie Review</a>
                            <a class="navbar-brand text-white" href="home.php#moviesList">Movies</a>
                        </div>

                        <!-- Login Option -->
                        <div class="collapse navbar-collapse col-lg-9 col-md-4 justify-content-end mt-3" id="navbarSupportedContent">
                            <form class="d-flex" method="GET" action="search.php">
                                <input class="form-control me-2 mt-1" type="search" placeholder="Search" aria-label="Search" name="q">
                                <button class="btn btn-light bg-transparent mt-1" style="color: white" type="submit">
                                    Search
                                </button>
                                <a class=" navbar-brand text-light fw-bold px-3 fs-4" href="signin.php"><u>Login</u></a>
                            </form>
                        </div>
                    </div>
                </nav>
            </div>
        </header>
        <?php
    }
}
?>
