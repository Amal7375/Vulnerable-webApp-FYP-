<?php
session_start();
if (isset($_SESSION['userId']) || isset($_SESSION['isAdmin'])) {
    session_destroy();
}
header("location: signin.php");
exit();
