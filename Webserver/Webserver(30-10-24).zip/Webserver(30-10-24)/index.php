<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "fyp");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch rooms from the database
$sql = "SELECT id, name FROM room";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Rooms</title>
    <link href="css/custom.css"        rel="stylesheet">

</head>
<body>
    <div class="room-container">
        <h1>Available Rooms</h1>

        <?php
        if ($result) {
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='room-card'>";
                    echo "<h2>" . htmlspecialchars($row['name']) . "</h2>";
                    echo "<form action='room.php' method='GET'>";
                    echo "<input type='hidden' name='id' value='" . htmlspecialchars($row['id']) . "'>";
                    echo "<button type='submit'>Join This Room</button>";
                    echo "</form>";
                    echo "</div>";
                }
            } else {
                echo "<p class='no-rooms'>No rooms available.</p>";
            }
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
