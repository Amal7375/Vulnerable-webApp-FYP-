<?php
session_start(); // Start the session

// Database connection
$conn = new mysqli("localhost", "root", "", "fyp");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// Get room details based on ID
$room_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$sql = "SELECT name, description, ip_address FROM room WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $room_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $room = $result->fetch_assoc();
    
    // Check if a box is currently running for this user
    $isBoxRunning = isset($_SESSION['running_box']) && $_SESSION['running_box'] == $room_id;

    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title><?php echo htmlspecialchars($room['name']); ?></title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="css/custom.css">

        <script>
            let timeSpent = 0; // Variable to track time spent in the box
            let interval; // Variable to store the timer interval

            window.onload = function() {
                // Disable start button if box is already running
                if (<?php echo json_encode($isBoxRunning); ?>) {
                    document.getElementById("startRoomButton").classList.add("hidden");
                    document.getElementById("stopVmButton").classList.remove("hidden");
                    document.getElementById("copyButton").classList.remove("hidden");
                    startTimer(); // Start the timer if the box is running
                }
            };

            function startRoomAndShowIp() {
                let timer = 5; // 5-second timer
                const timerElement = document.getElementById("timer");
                const ipAddressElement = document.getElementById("ipAddress");
                const copyButton = document.getElementById("copyButton");
                const startRoomButton = document.getElementById("startRoomButton");

                startRoomButton.classList.add("hidden");
                timerElement.classList.remove("hidden");

                const countdown = setInterval(() => {
                    timerElement.textContent = "Starting room and showing IP in " + timer + " seconds...";
                    if (timer === 0) {
                        clearInterval(countdown);
                        timerElement.classList.add("hidden");
                        ipAddressElement.classList.remove("hidden");
                        copyButton.classList.remove("hidden");

                        // Send request to start the box after 5 seconds
                        startAttackBox();
                    }
                    timer--;
                }, 1000);
            }

            function startAttackBox() {
                const xhr = new XMLHttpRequest();
                xhr.open("GET", "startVm.php?id=<?php echo $room_id; ?>", true);
                xhr.onload = function () {
                    if (xhr.status === 200) {
                        alert(xhr.responseText);
                        document.getElementById("startRoomButton").classList.add("hidden");
                        document.getElementById("stopVmButton").classList.remove("hidden"); // Show stop button
                        document.getElementById("copyButton").classList.remove("hidden"); // Show copy button
                        startTimer(); // Start the timer for time spent

                        // Set session variable to indicate a box is running
                        const xhrUpdateSession = new XMLHttpRequest();
                        xhrUpdateSession.open("GET", "updateSession.php?running_box=<?php echo $room_id; ?>", true);
                        xhrUpdateSession.send();
                    } else {
                        alert("Failed to start box");
                    }
                };
                xhr.send();
            }

            function startTimer() {
                document.getElementById("timer").classList.remove("hidden"); // Show timer
                interval = setInterval(() => {
                    timeSpent++;

                    // Calculate hours, minutes, and seconds
                    const hours = Math.floor(timeSpent / 3600);
                    const minutes = Math.floor((timeSpent % 3600) / 60);
                    const seconds = timeSpent % 60;

                    // Format the time display
                    let timeString = "";
                    if (hours > 0) {
                        timeString += hours + " hour" + (hours > 1 ? "s" : "") + " ";
                    }
                    if (minutes > 0 || hours > 0) { // Include minutes if there are hours
                        timeString += minutes + " minute" + (minutes > 1 ? "s" : "") + " ";
                    }
                    timeString += seconds + " second" + (seconds !== 1 ? "s" : "");

                    document.getElementById("timer").textContent = "Time spent in VM: " + timeString;
                }, 1000);
            }

            function stopVm() {
                const xhr = new XMLHttpRequest();
                const roomId = "<?php echo $room_id; ?>";
                xhr.open("GET", "stopVm.php?id=" + roomId, true);
                xhr.onload = function () {
                    if (xhr.status === 200) {
                        alert("Box stopped successfully");
                        clearInterval(interval); // Stop the timer
                        document.getElementById("stopVmButton").classList.add("hidden"); // Hide stop button
                        document.getElementById("copyButton").classList.add("hidden"); // Hide copy button
                        timeSpent = 0; // Reset time spent

                        // Update session variable to indicate the box is not running
                        const xhrUpdateSession = new XMLHttpRequest();
                        xhrUpdateSession.open("GET", "updateSession.php?running_box=0", true);
                        xhrUpdateSession.send();
                    } else {
                        console.error("Error stopping VM. Status:", xhr.status);
                        alert("Failed to stop box");
                    }
                };
                xhr.onerror = function () {
                    console.error("Request failed to reach the server.");
                    alert("Failed to stop box. Network error.");
                };
                xhr.send();
            }
            
            function copyToClipboard() {
                const ipAddress = document.getElementById("ipAddress").textContent;
                navigator.clipboard.writeText(ipAddress).then(() => {
                    alert("IP Address copied to clipboard!");
                });
            }
        </script>
    </head>
    <body>
        <div class="room-container">
            <h1><?php echo htmlspecialchars($room['name']); ?></h1>
            <p><?php echo htmlspecialchars($room['description']); ?></p>

            <button id="startRoomButton" class="button" onclick="startRoomAndShowIp()">Start Room</button>
            <p id="timer" class="timer hidden"></p>

            <p id="ipAddress" class="hidden"><?php echo htmlspecialchars($room['ip_address']); ?></p>
            <button id="copyButton" class="copy-button hidden" onclick="copyToClipboard()">Copy IP Address</button>

            <button id="startAttackBoxButton" class="attack-box-button hidden" onclick="startAttackBox()">Start Attack Box</button>
            <button id="stopVmButton" class="stop-vm-button hidden" onclick="stopVm()">Stop VM</button><br><br>

            <a href="index.php" class="back-link">Back to Room List</a>
        </div>
    </body>
    </html>

    <?php
} else {
    echo "<p>Room not found.</p>";
}

$stmt->close();
$conn->close();
?>
