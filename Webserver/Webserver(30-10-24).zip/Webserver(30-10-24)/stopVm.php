<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "fyp");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve vmrun path from config table
$sql = "SELECT setting_value FROM config WHERE setting_name = 'vmrun_path'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $vmrun_path = $row['setting_value'];
} else {
    die("VMrun path not found in config table.");
}

// Get room ID and retrieve VM path from room table
$room_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$sql = "SELECT vm_path FROM room WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $room_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $vm_path = $row['vm_path'];
} else {
    die("VM not found.");
}

// Command to stop the VM
$command = escapeshellarg($vmrun_path) . " stop " . escapeshellarg($vm_path) . " nogui 2>&1";

// Execute command and capture output
$output = shell_exec($command);

// Check for success or error output
if (strpos($output, 'Error') !== false) {
    echo "Failed to stop VM: " . htmlspecialchars($output);
} else {
    echo "VM stopped successfully.";
}

// Close the connection
$conn->close();
?>
