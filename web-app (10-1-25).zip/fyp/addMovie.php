<form method="post" action="admin.php">
    <h3>Add Movie</h3>
    <input type="text" name="titlee" placeholder="Title" required><br>
    <input type="text" name="genre" placeholder="Genre" required><br>
    <input type="text" name="director" placeholder="Director" required><br>
    <input type="text" name="cast" placeholder="Cast" required><br>
    <textarea name="synopsis" placeholder="Synopsis"></textarea><br>
    <input type="text" name="picture" placeholder="Picture Filename"><br>
    <button type="submit" name="addMovie">Add Movie</button>
</form>
