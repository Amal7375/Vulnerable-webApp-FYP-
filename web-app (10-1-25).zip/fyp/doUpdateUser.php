<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<?php
// Starting a new session
session_start();

// Checking if the form was submitted
if (isset($_POST["submit"])) {
    // Checking if the user is logged in
    if (isset($_SESSION["userId"])) {
        // Including the database connection file
        include_once './dbhConnect.php';

        // Extracting user data from the POST request
        $userId = $_SESSION["userId"];
        $userName = $_POST['name'];
        $userPassword = $_POST['password'];
        $userEmail = $_POST['email'];
        $userDob = $_POST['dob'];
        $userPassword = SHA1($userPassword);
        // Checking the database connection
        if (!$link) {
            echo 'Connection error';
            exit();
        } else {
            // Constructing the SQL query for updating user information
            if ($userPassword == "R@nd0mT3sct") {
                $query = "UPDATE users SET name = '$userName', dob = '$userDob', email='$userEmail'  WHERE userId = '$userId'";
            } else {
                $query = "UPDATE users SET password = '$userPassword', name = '$userName', dob = '$userDob', email='$userEmail'  WHERE userId = '$userId'";
            }

            // Executing the SQL query
            $result = mysqli_query($link, $query) or die(mysqli_error($link));

            // Checking if the query was successful
            if (!$result) {
                header('location:./userProfile.php?error');
            } else {
                header('location:./userProfile.php?Success');

                // Constructing a new query to fetch updated user data
                $query = "SELECT * FROM users WHERE userId = '$userId'";

                // Executing the query to fetch user data
                $result = mysqli_query($link, $query) or die(mysqli_error($link));

                // Checking if user data was retrieved successfully
                if (mysqli_num_rows($result) > 0) {
                    // Fetching user data and updating session variables
                    $result = mysqli_fetch_array($result);
                    $_SESSION['userId'] = $result['userId'];
                    $_SESSION['username'] = $result['username'];
                    $_SESSION['name'] = $result['name'];
                    $_SESSION['dob'] = $result['dob'];
                    $_SESSION['email'] = $result['email'];
                }
            }
        }
    }
} else {
    // Redirecting to user profile page with an error message
    header('location:./userProfile.php?error');
}
?>


<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
