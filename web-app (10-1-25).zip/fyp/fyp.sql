-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 04, 2025 at 03:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fyp`
--

-- --------------------------------------------------------

--
-- Table structure for table `additionalmoviedetails`
--

CREATE TABLE `additionalmoviedetails` (
  `movieId` int(11) NOT NULL,
  `pic1` varchar(30) NOT NULL,
  `pic2` varchar(30) NOT NULL,
  `pic3` varchar(30) NOT NULL,
  `link` varchar(300) NOT NULL,
  `pic4` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `additionalmoviedetails`
--

INSERT INTO `additionalmoviedetails` (`movieId`, `pic1`, `pic2`, `pic3`, `link`, `pic4`) VALUES
(1, 'jw1.jpeg', 'jw2.jpeg', 'jw3.jpeg', 'https://www.youtube-nocookie.com/embed/yjRHZEUamCc', 'jw4.jpeg'),
(2, 'mp1.jpeg', 'mp2.jpeg', 'mp3.jpeg', 'https://www.youtube.com/embed/G_j77zueLF4', 'mp4.jpeg'),
(3, 'se1.jpeg', 'se2.jpeg', 'se3.jpeg', 'https://www.youtube-nocookie.com/embed/5pTcio2hTSw', 'se4.jpeg'),
(4, 'av1.jpeg', 'av2.jpeg', 'av3.jpeg', 'https://www.youtube-nocookie.com/embed/d9MyW72ELq0', 'av4.jpeg'),
(5, 'mm1.jpeg', 'mm2.jpeg', 'mm3.jpeg', 'https://www.youtube-nocookie.com/embed/WRB8YIc4U68', 'mm4.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `movieId` int(11) NOT NULL,
  `movieTitle` varchar(80) NOT NULL,
  `movieGenre` varchar(80) NOT NULL,
  `runningTime` varchar(20) NOT NULL,
  `language` varchar(60) NOT NULL,
  `picture` varchar(60) NOT NULL,
  `director` varchar(80) NOT NULL,
  `cast` text NOT NULL,
  `synopsis` text NOT NULL,
  `carouselImg` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`movieId`, `movieTitle`, `movieGenre`, `runningTime`, `language`, `picture`, `director`, `cast`, `synopsis`, `carouselImg`) VALUES
(1, 'John Wick: Chapter 4', 'Action/ Thriller', '170 minutes', 'English(Sub: Chinese, Malay)', 'JohnWick.png', 'Chad Stahelski', 'Keanu Reeves, Donnie Yen, Bill Skarsgard, Laurence Fishburne, Hiroyuki Sanada, Lance Reddick, Scott Adkins', 'John Wick (Keanu Reeves) uncovers a path to defeating The High Table. But before he can earn his freedom, Wick must face off against a new enemy with powerful alliances across the globe and forces that turn old friends into foes.', 'JohnWick.jpg'),
(2, 'My Puppy', 'Drama', '113 minutes', 'Korean(Sub: English, Chinese)', 'mypuppy.png', 'Jason Kim', 'Yoo Yeon-seok, Cha Tae-hyun', 'Min-soo (Yoo Yeon-seok) is an ordinary office worker who dreams of a perfect family. He has a dog, Rooney, whom he treats as a younger brother. Unexpected circumstances arises in Min-soo\'s life, when he can no longer live with Rooney ahead of his marriage with his fiancee who is allergic to dogs. Together with his cousin, Jin-guk (Cha Tae-hyun) who owns a cafe that went bankrupt, Min-soo decides to find a new family for Rooney. On their journey that starts in Seoul and continues to Jeju Island to find the perfect owner, the two encounter the heart-breaking reality of abandoned pets.', 'mypuppies.jpeg'),
(3, 'Suzume', 'Animation', '122 minutes', 'Japanese(Sub: English, Chinese)', 'suzume.png', 'Makoto Shinkai', 'Nanoka Hara, Hokuto Matsumura, Eri Fukatsu', 'On the other side of the door, was time in its entirety.\r\n\r\n\"Suzume\" is a coming-of-age story for the 17-year-old protagonist, Suzume, set in various disaster-stricken locations across Japan, where she must close the doors causing devastation. \r\n\r\nSuzume\'s journey begins in a quiet town in Kyushu (located in southwestern Japan) when she encounters a young man who tells her, \"I\'m looking for a door.\" What Suzume finds is a single weathered door standing upright in the midst of ruins as though it was shielded from whatever catastrophe struck. Seemingly drawn by its power, Suzume reaches for the knob. Doors begin to open one after another all across Japan, unleashing destruction upon any who are near. Suzume must close these portals to prevent further disaster. The stars, then sunset, and the morning sky.\r\n', 'suzume.png'),
(4, 'Avatar: The Way Of Water', 'Action/ Adventure/ Fantasy', '192 minutes', 'English(Sub: Chinese)', 'avatar.png', 'James Cameron', 'Sam Worthington, Zoe Saldana, Sigourney Weaver, Kate Winslet, Vin Diesel, Stephen Lang', 'Set more than a decade after the events of the first film, \"Avatar: The Way of Water\" begins to tell the story of the Sully family (Jake, Neytiri, and their kids), the trouble that follows them, the lengths they go to keep each other safe, the battles they fight to stay alive, and the tragedies they endure.\r\n', 'avatar.jpg'),
(5, 'Mummies', 'Animation', '89 minutes', 'English(Sub: Chinese', 'mummies.png', 'Juan Jesus Garcia Galocha', 'Sean Bean, Hugh Bonneville, Eleanor Tomlinson, Celia Imrie, Joe Thomas, Dan Starkey', 'It follows three mummies as they end up in present-day London and embark on a journey in search of an old ring belonging to the Royal Family, stolen by the ambitious archaeologist Lord Carnaby.', 'mummies.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `reviewId` int(11) NOT NULL,
  `movieId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `review` text NOT NULL,
  `rating` int(11) NOT NULL,
  `datePosted` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`reviewId`, `movieId`, `userId`, `review`, `rating`, `datePosted`) VALUES
(2, 2, 1, 'Heartwarming show, definitely worth a watch', 5, '2023-04-04'),
(7, 4, 13, 'Test Comment', 3, '2023-07-05'),
(10, 1, 13, 'asdgfasdf', 3, '2024-12-11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(40) NOT NULL,
  `name` varchar(80) NOT NULL,
  `dob` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `role` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `dob`, `email`, `role`) VALUES
(1, 'peter', 'peterlim', 'Peter Lim', '2008-08-13', 'peter@gmail.com', 'usr'),
(4, 'john', 'johnHo', 'John Ho', '2005-12-11', 'JohnHo@gmail.com', 'usr'),
(5, 'sally', 'sallyLim', 'Sally Lim', '1989-02-10', 'sally@gmail.com', 'usr'),
(13, 'Amal', '7a671c37cb54c6697b951e2d1519f2d53de2e78f', 'amal', '2023-06-22', 'Amal@amal', 'adm'),
(14, 'newUser', '9d4e1e23bd5b727046a9e3b4b7db57bd8d6ee684', 'user', '2023-06-29', 'new@gmIL', 'usr'),
(17, 'Admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Administrator', '1993-03-11', 'Adminstrator.movireReview@gmail.com', 'adm'),
(18, 'sharon', 'sharon', 'sharon', '2024-12-11', 'sharon@gmail.com', 'usr');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `additionalmoviedetails`
--
ALTER TABLE `additionalmoviedetails`
  ADD PRIMARY KEY (`movieId`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`movieId`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`reviewId`),
  ADD KEY `Foreign Key` (`movieId`),
  ADD KEY `Foreign Key (User)` (`userId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `additionalmoviedetails`
--
ALTER TABLE `additionalmoviedetails`
  MODIFY `movieId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `movieId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `reviewId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `Foreign Key` FOREIGN KEY (`movieId`) REFERENCES `movies` (`movieId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Foreign Key (User)` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
