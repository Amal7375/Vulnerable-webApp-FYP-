
<!DOCTYPE html>
<?php
session_start();

include_once './dbhConnect.php';
$query1 = "SELECT * FROM movies";
$result1 = mysqli_query($link, $query1);

while ($row1 = mysqli_fetch_assoc($result1)) {
    $row[] = $row1;
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Movie List</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

        <style>
    /* Fullscreen video styling */
    .background-video {
        position: fixed; /* Ensures it stays fixed in the viewport */
        top: 0;
        left: 0;
        width: 100vw; /* 100% of the viewport width */
        height: 100vh; /* 100% of the viewport height */
        object-fit: cover; /* Ensures the video covers the entire screen without distortion */
        z-index: -1; /* Keeps the video behind all content */
    }
</style>

<script>
    // Fallback: Ensure the video loops using JavaScript
    const video = document.getElementById('bg-video');
    video.addEventListener('ended', () => {
        video.currentTime = 0; // Restart the video
        video.play(); // Play the video again
    });
</script>
    </head>
    <body class="">

        <!-- Background video -->
        <video class="background-video" autoplay muted loop id="bg-video">
    <source src="images/bg.mp4" type="video/mp4">
    Your browser does not support the video tag.
</video>

        <!-- Color overlay -->
        <div class="color-overlay"></div>
        
        <?php
        // Including the header file
        include_once './header.php';
        ?>

        <section>
            <div class="">
                <div class="container">
                    <div class="row">
                        <!-- Carousel for displaying images -->
                        <div id="carouselImages" class="carousel slide carousel-fade" data-bs-ride="carousel" style="width: 100%; height: 75%">
                            <div class="carousel-inner">
                                <?php
                                // Loop through images to create carousel items
                                for ($i = 0; $i < count($row); $i++) {
                                    ?>
                                    <div class="carousel-item <?php echo ($i === 0) ? 'active' : ''; ?>">
                                        <img src="images/extra/<?php echo $row[$i]['carouselImg']; ?>" class="d-block w-100" alt="Image <?php echo $i; ?>">
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                            <!-- Carousel navigation buttons -->
                            <button class="carousel-control-prev" type="button" data-bs-target="#carouselImages" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#carouselImages" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="">
                <div class="container">
                    <div class="row" id="moviesList">
                        <?php
                        // Loop through movies to display movie cards
                        for ($i = 0; $i < count($row); $i++) {
                            $synopsis = $row[$i]['synopsis'];
                            if (strlen($synopsis) > 200) {
                                $synopsis = substr($synopsis, 0, 200) . '...';
                            }
                            ?>
                            <div class="col-md-4 d-flex">
                                <div class="card m-5 flex-fill">
                                    <img src="images/<?php echo $row[$i]['picture']; ?>" class="card-img-top" style="height: 60%" alt="movieImg">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo $row[$i]['movieTitle']; ?></h5>
                                        <p class="card-text"><b><?php echo $row[$i]['movieTitle']; ?></b>: <?php echo $synopsis; ?></p>
                                        <div class="d-flex justify-content-center">
                                            <form action="movieInfo.php" method="get">
                                                <!-- Button to view more movie info -->
                                                <button type="submit" class="btn btn-info" name="id" value="<?php echo $row[$i]['movieId']; ?>">More</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </section>

        <?php
        // Including the footer file
        include_once './footer.php';
        ?>
    </body>
</html>
