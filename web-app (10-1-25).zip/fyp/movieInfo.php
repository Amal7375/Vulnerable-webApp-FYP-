<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.25.0/font/bootstrap-icons.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    </head>
    <body class="bg-dark">
        <?php
        session_start();

        $_SESSION['movieId'] = $_GET['id'];

        include_once './dbhConnect.php';

        #Check database connection

        if (!$link) {
            header('location:./home.php/NotAbleToConnect');
        } else {
            $id = $_GET['id'];
            $query = "SELECT * FROM movies WHERE movieId = '$id'";
            $query2 = "SELECT * FROM additionalmoviedetails WHERE movieId = '$id'";

            $result = mysqli_query($link, $query);
            $result2 = mysqli_query($link, $query2);

            #check for movie
            if (mysqli_num_rows($result) && mysqli_num_rows($result2) > 0) {
                $row = mysqli_fetch_assoc($result);
                $row2 = mysqli_fetch_assoc($result2);

                #Headder
                include_once './header.php';
                ?>
                <section>
                    <!-- Movie Content -->
                    <div class="row bg-dark ">
                        <div class="container">
                            <!-- Movie Details and Video -->
                            <div class="row justify-content-between m-5">
                                <!-- Movie Details Column -->
                                <div class="col-md-6 px-auto">
                                    <div class="d-flex flex-row mb-3 col-xm-3 col-md-12">
                                        <!-- Movie Thumbnail -->
                                        <div class="p-2 bd-highlight ">
                                            <img src="images/<?php echo $row['picture']; ?>" class="img-fluid img-thumbnail" style="width:100px; height: 150px" alt="thumbnail"/>
                                        </div>
                                        <!-- Movie Title and Genre -->
                                        <div class="p-2 bd-highlight text-center w-50 col-12">
                                            <h1 class="text-center text-white m-auto"><b><?php echo $row['movieTitle']; ?></b></h1><br>
                                            <button class="btn btn-light rounded-pill"><?php echo $row['movieGenre']; ?></button>
                                        </div>
                                    </div>
                                    <!-- Movie Details -->
                                    <div>
                                        <p class="text-white">
                                            <b><i>Director</i></b> : <?php echo $row['director']; ?><br> 
                                            <b>Cast</b> : <?php echo $row['cast']; ?><br> <br>
                                            <?php echo $row['synopsis']; ?>
                                        </p>
                                    </div>
                                </div>
                                <!-- Movie Video Column -->
                                <div class="col-md-6 px-auto bg-dark">
                                    <div class="ratio m-auto" style="--bs-aspect-ratio: 50%">
                                        <!-- YouTube Video Embed -->
                                        <iframe src="<?php echo $row2['link']; ?>" title="YouTube video" allowfullscreen class="embed-responsive-item"></iframe><br>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section>
                    <div class="bg-dark m-auto " >
                        <div id="carouselImages" class="carousel slide " data-bs-ride="carousel" data-bs-interval="2500">
                            <div class="carousel-inner ">
                                <div class="carousel-item active">
                                    <div class="row ">
                                        <div class="col-3">
                                            <img src="images/extra/<?php echo $row2['pic1']; ?>" class="d-block w-75" style="width:25%; height: 75%"  alt="Image 1">
                                        </div>
                                        <div class="col-3">
                                            <img src="images/extra/<?php echo $row2['pic2']; ?>" class="d-block w-75" style="width:25%; height: 75%" alt="Image 2" alt="Image 2">
                                        </div>
                                        <div class="col-3">
                                            <img src="images/extra/<?php echo $row2['pic3']; ?>" class="d-block w-75" style="width:25%; height: 75%" alt="Image 3" alt="Image 3">
                                        </div>
                                        <div class="col-3">
                                            <img src="images/extra/<?php echo $row2['pic4']; ?>" class="d-block w-75" style="width:25%; height: 75%" alt="Image 4" alt="Image 4">
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="row">
                                        <div class="col-3">
                                            <img src="images/extra/<?php echo $row2['pic3']; ?>" class="d-block w-75" style="width:25%; height: 75%" alt="Image 3" alt="Image 3">
                                        </div>
                                        <div class="col-3">
                                            <img src="images/extra/<?php echo $row2['pic4']; ?>" class="d-block w-75" style="width:25%; height: 75%" alt="Image 2" alt="Image 4">
                                        </div>
                                        <div class="col-3">
                                            <img src="images/extra/<?php echo $row2['pic1']; ?>" class="d-block w-75" style="width:25%; height: 75%" alt="Image 4" alt="Image 1">
                                        </div>
                                        <div class="col-3">
                                            <img src="images/extra/<?php echo $row2['pic2']; ?>" class="d-block w-75" style="width:25%; height: 75%" alt="Image 1" alt="Image 2">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section><br>
                <section>
                    <div class="container ">

                        <!-- Customer reviews and Ratings -->

                        <?php
                        $qurey3 = "SELECT * FROM reviews WHERE movieId = '$id'";
                        $result3 = mysqli_query($link, $qurey3);

                        $rating = 0;
                        $numberOfRating = 0;
                        $fiveStr = 0;
                        $fourStr = 0;
                        $threeStr = 0;
                        $twoStr = 0;
                        $oneStr = 0;

                        if (!mysqli_num_rows($result3) > 0) {
                            echo 'No rating';
                            $totalRating = 0;
                        } else {

                            while ($row3 = mysqli_fetch_assoc($result3)) {
                                echo 'error';
                                $ratingVal = $row3['rating'];
                                $rating += $ratingVal;
                                $numberOfRating += 1;

                                if ($ratingVal == 5) {
                                    $fiveStr += 1;
                                } else if ($ratingVal == 4) {
                                    $fourStr += 1;
                                } else if ($ratingVal == 3) {
                                    $threeStr += 1;
                                } else if ($ratingVal == 2) {
                                    $twoStr += 1;
                                } else if ($ratingVal == 1) {
                                    $oneStr += 1;
                                }
                            }

                            $totalRating = $rating / $numberOfRating;

                            if ($totalRating > 0 && $totalRating <= 0.5) {
                                $totalRating = 0.5;
                            } else if ($totalRating > 0.5 && $totalRating <= 1) {
                                $totalRating = 1;
                            } else if ($totalRating > 1 && $totalRating <= 1.5) {
                                $totalRating = 1.5;
                            } else if ($totalRating > 1.5 && $totalRating <= 2) {
                                $totalRating = 2;
                            } else if ($totalRating > 2 && $totalRating <= 2.5) {
                                $totalRating = 2.5;
                            } else if ($totalRating > 2.5 && $totalRating <= 3) {
                                $totalRating = 3;
                            } else if ($totalRating > 3 && $totalRating <= 3.5) {
                                $totalRating = 3.5;
                            } else if ($totalRating > 3.5 && $totalRating <= 4) {
                                $totalRating = 4;
                            } else if ($totalRating > 4 && $totalRating <= 4.5) {
                                $totalRating = 4.5;
                            } else {
                                $totalRating = 5;
                            }
                        }
                        ?>
                        <div class="card bg-dark text-light">
                            <div class="card-header ">
                                <h3 class="card-title fs-1 text-center"><i><b>Ratings And Reviews</b></i></h3>
                            </div><br><br>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="card bg-dark">
                                            <div class="card-header text-center">
                                                <h3>Rating</h3>
                                            </div>
                                            <div class="card-body">
                                                <div class="d-flex align-items-center">
                                                    <div class="pt-3 bg-dark col-md-6  ms-4" style="width: 45%">
                                                        <!-- Star Rating -->
                                                        <?php
                                                        if ($totalRating != 0) {
                                                            $findTheInt = ($totalRating / .5);
                                                            $ratingTotal = $totalRating;
                                                            if ($findTheInt % 2 === 0) {
                                                                while ($ratingTotal != 0) {
                                                                    ?>
                                                                    <span class="fa fa-lg fa-star checked" style="color: #ffda24"></span>
                                                                    <?php
                                                                    $ratingTotal -= 1;
                                                                }
                                                            } else {
                                                                while ($ratingTotal > 0) {
                                                                    if ($ratingTotal > 1) {
                                                                        ?>
                                                                        <span class="fa fa-lg fa-star checked" style="color: #ffda24"></span>
                                                                        <?php
                                                                        $ratingTotal -= 1;
                                                                    } else {
                                                                        ?>
                                                                        <span class="fa fa-lg fa-star-half-alt checked" style="color: #ffda24"></span>

                                                                        <?php
                                                                        $ratingTotal -= .5;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        if ($totalRating < 4.5) {
                                                            $reminder = 5 - $totalRating;

                                                            while ($reminder > 0) {
                                                                ?>
                                                                <span class="far fa-lg fa-star" style="color: white;"></span>
                                                                <?php
                                                                $reminder -= 1;
                                                            }
                                                        }
                                                        ?>

                                                    </div>
                                                    <div class="w-50 bg-dark pt-4 col-md-6">
                                                        <h4><?php echo "$totalRating" ?> out of 5</h4>
                                                    </div>
                                                </div>
                                                <h6 class="mx-4 my-2"><?php echo "$numberOfRating" ?> Reviews</h6><br>
                                                <div>
                                                    <!-- Percentage Calculation -->

                                                    <?php
                                                    if ($fiveStr > 0) {
                                                        $fiveStr = ($fiveStr / $numberOfRating) * 100;
                                                        $fiveStr = round($fiveStr, 2);
                                                    }
                                                    if ($fourStr > 0) {
                                                        $fourStr = ($fourStr / $numberOfRating) * 100;
                                                        $fourStr = round($fourStr, 2);
                                                    }
                                                    if ($threeStr > 0) {
                                                        $threeStr = ($threeStr / $numberOfRating) * 100;
                                                        $threeStr = round($threeStr, 2);
                                                    }
                                                    if ($twoStr > 0) {
                                                        $twoStr = ($twoStr / $numberOfRating) * 100;
                                                        $twoStr = round($twoStr, 2);
                                                    }
                                                    if ($oneStr > 0) {
                                                        $oneStr = ($oneStr / $numberOfRating) * 100;
                                                        $oneStr = round($oneStr, 2);
                                                    }
                                                    ?>
                                                    <!-- 5 Star -->
                                                    <div class="d-flex align-items-center">
                                                        <h6>5 <span class="fa fa-star checked mt-1" style="color: #ffda24"></span></h6>
                                                        <div class="progress flex-grow-1 ms-3">
                                                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo"$fiveStr" ?>%" aria-valuenow="<?php echo"$fiveStr" ?>" aria-valuemin="0" aria-valuemax="100"><?php echo"$fiveStr" ?>%</div>
                                                        </div>
                                                    </div><br>

                                                    <!-- 4 Star -->
                                                    <div class="d-flex align-items-center">
                                                        <h6>4<span class="fa fa-star checked mt-1" style="color: #ffda24"></span></h6>
                                                        <div class="progress flex-grow-1 ms-3">
                                                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo"$fourStr" ?>%" aria-valuenow="<?php echo"$fourStr" ?>" aria-valuemin="0" aria-valuemax="100"><?php echo"$fourStr" ?>%</div>
                                                        </div>
                                                    </div><br>

                                                    <!-- 3 Star -->
                                                    <div class="d-flex align-items-center">
                                                        <h6>3 <span class="fa fa-star checked mt-1" style="color: #ffda24"></span></h6>
                                                        <div class="progress flex-grow-1 ms-3">
                                                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo"$threeStr" ?>%" aria-valuenow="<?php $threeStr ?>" aria-valuemin="0" aria-valuemax="100"><?php echo"$threeStr" ?>%</div>
                                                        </div>
                                                    </div><br>

                                                    <!-- 2 Star -->
                                                    <div class="d-flex align-items-center">
                                                        <h6>2 <span class="fa fa-star checked mt-1" style="color: #ffda24"></span></h6>
                                                        <div class="progress flex-grow-1 ms-3">
                                                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo"$twoStr" ?>%" aria-valuenow="<?php echo"$twoStr" ?>" aria-valuemin="0" aria-valuemax="100"><?php echo"$twoStr" ?>%</div>
                                                        </div>
                                                    </div><br>

                                                    <!-- 1 Star -->
                                                    <div class="d-flex align-items-center">
                                                        <h6>1 <span class="fa fa-star checked mt-1" style="color: #ffda24"></span></h6>
                                                        <div class="progress flex-grow-1 ms-3">
                                                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo"$oneStr" ?>%" aria-valuenow="<?php echo"$oneStr" ?>" aria-valuemin="0" aria-valuemax="100"><?php echo"$oneStr" ?>%</div>
                                                        </div>
                                                    </div><br>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Customer Review -->


                                    <div class="col-md-6">
                                        <div class="bg-dark">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-10 col-md-12  " >
                                                        <div class="card bg-dark ">
                                                            <div class="card-header text-center">
                                                                <h3>Write Review</h3>
                                                            </div>
                                                            <div class="card-body">
                                                                <!-- Review and Rating Form --> 
                                                                <?php
                                                                if (isset($_SESSION['userId'])) {
                                                                    $action = "movieReview.php";

                                                                    if (isset($_GET['reviewFound'])) {
                                                                        echo '<div class="alert alert-danger"><b>Revew Found.</b></div>';
                                                                    } else if (isset($_GET['error'])) {
                                                                        echo '<div class="alert alert-danger"><b>Try Again.</b></div>';
                                                                    } else if (isset($_GET['Success'])) {
                                                                        echo '<div class="alert alert-success"><b>Thanks for your review.</b></div>';
                                                                    }
                                                                } else {
                                                                    $action = 'signin.php';
                                                                }
                                                                ?> 
                                                                <form class="was-validated" action=<?php echo $action ?> method="post" >
                                                                    <div class="form-group text-light">
                                                                        <label for="rating"><b><i>Rating: </i></b></label><br><br>
                                                                        <div class="rating form-check  mx-3">

                                                                            <label for="star1" class="me-2"><b>1</b></label>
                                                                            <label for="star2" class="mx-2"><b>2</b></label>
                                                                            <label for="star3" class="mx-2"><b>3</b></label>
                                                                            <label for="star4" class="mx-2"><b>4</b></label>
                                                                            <label for="star5" class="mx-2"><b>5</b></label><br>

                                                                            <input type="radio" id="star1" class="form-check-input" style="margin-left:0" name="rating" value="1" required/>
                                                                            <input type="radio" id="star2" class="form-check-input" style="margin-left: 12px"name="rating" value="2" />
                                                                            <input type="radio" id="star3" class="form-check-input" style="margin-left: 12px"name="rating" value="3" />
                                                                            <input type="radio" id="star4" class="form-check-input" style="margin-left: 12px"name="rating" value="4" />    
                                                                            <input type="radio" id="star5" class="form-check-input" style="margin-left: 12px"name="rating" value="5" /> <br>


                                                                        </div>
                                                                    </div><br>

                                                                    <div class="form-group text-light ">
                                                                        <label for="review"><b><i>Review</i></b></label>
                                                                        <textarea class="form-control " id="review" name="review" required></textarea>
                                                                    </div><br>


                                                                    <div class="d-flex justify-content-center">
                                                                        <button type="submit" name="submit" value="submit" class="btn btn-success ">Submit</button>
                                                                    </div>

                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>    
                                </div>

                                <div class="card mt-4 bg-dark text-light">
                                    <div class="card-header">
                                        <h2 class="card-title text-center"><b>User Reviews</b></h2>
                                    </div>

                                    <?php
                                    if (isset($_SESSION['userId'])) {
                                        if (isset($_GET['deleted'])) {
                                            echo '<div class="alert alert-success"><b>Review Deleted.</b></div>';
                                        } else if (isset($_GET['updated'])) {
                                            echo '<div class="alert alert-success"><b>Review Updated.</b></div>';
                                        }
                                    }

                                    $call = mysqli_query($link, $qurey3);
                                    if ($totalRating != 0) {
                                        while ($row3 = mysqli_fetch_assoc($call)) {
                                            $userId = $row3['userId'];
                                            $qurey4 = "SELECT * FROM users WHERE id = '$userId'";
                                            $result4 = mysqli_query($link, $qurey4);
                                            if (mysqli_num_rows($result4) == 0) {
                                                ?>
                                                <h1>No Reviews</h1>
                                                <?php
                                            } else {
                                                while ($row4 = mysqli_fetch_assoc($result4)) {
                                                    $user = $row4['name'];
                                                    $comment = $row3['review'];
                                                    $date = $row3['datePosted'];
                                                    $usrRating = $row3['rating'];
                                                    ?>
                                                    <div class="card-body">
                                                        <div class="media mb-4">
                                                            <div class="media-body">
                                                                <img src="./images/avatar.webp" class="mr-3 rounded-circle d-inline" alt="User Avatar" width="44" height="44">
                                                                <h5 class="mt-0 d-inline ps-2"><?php echo "$user"; ?></h5>
                                                                <p class="d-inline ps-3"><?php echo "$usrRating"; ?></p>
                                                                <span class="fa fa-sm fa-star checked d-inline" style="color: #ffda24"></span>

                                                                <?php
                                                                if (isset($_SESSION['userId'])) {
                                                                    if ($userId == $_SESSION['userId']) {
                                                                        $thisUsrRating = $row3['rating'];
                                                                        $thiUsrComment = $row3['review'];
                                                                        ?>
                                                                        <!--Add the three dots dropdown  -->

                                                                        <div class = "dropdown d-inline">
                                                                            <button class = "btn btn-sm btn-link dropdown-toggle" type = "button" id = "commentOptionsDropdown" data-bs-toggle = "dropdown" aria-expanded = "false">
                                                                                <i class = "bi bi-three-dots-vertical"></i>
                                                                            </button>
                                                                            <ul class = "dropdown-menu dropdown-menu-end" aria-labelledby = "commentOptionsDropdown">
                                                                                <li><a class = "dropdown-item " data-bs-toggle="modal" data-bs-target="#exampleModal">Edit</a></li>
                                                                                <li><a class = "dropdown-item" href = "doDeleteReview.php">Delete</a></li>
                                                                            </ul>
                                                                        </div>

                                                                        <!-- modal -->

                                                                        <div class="modal fade" id="exampleModal"   >
                                                                            <div class="modal-dialog">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header bg-dark">
                                                                                        <h5 class="modal-title text-light" id="exampleModalLabel">Edit Comment</h5>
                                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                                    </div>
                                                                                    <form class="was-validated" action="doUpdateReview.php" method="post" >

                                                                                        <div class="modal-body bg-dark">
                                                                                            <div class="form-group text-light">
                                                                                                <label for="rating"><b><i>Rating: </i></b></label><br><br>
                                                                                                <div class="rating form-check  mx-3">

                                                                                                    <label for="star1" class="me-2"><b>1</b></label>
                                                                                                    <label for="star2" class="mx-2"><b>2</b></label>
                                                                                                    <label for="star3" class="mx-2"><b>3</b></label>
                                                                                                    <label for="star4" class="mx-2"><b>4</b></label>
                                                                                                    <label for="star5" class="mx-2"><b>5</b></label><br>

                                                                                                    <input type="radio" id="star1" class="form-check-input" style="margin-left: 0" name="rating" value="1" <?php if ($thisUsrRating == '1') echo 'checked'; ?> required/>
                                                                                                    <input type="radio" id="star2" class="form-check-input" style="margin-left: 12px" name="rating" value="2" <?php if ($thisUsrRating == '2') echo 'checked'; ?> />
                                                                                                    <input type="radio" id="star3" class="form-check-input" style="margin-left: 12px" name="rating" value="3" <?php if ($thisUsrRating == '3') echo 'checked'; ?> />
                                                                                                    <input type="radio" id="star4" class="form-check-input" style="margin-left: 12px" name="rating" value="4" <?php if ($thisUsrRating == '4') echo 'checked'; ?> />    
                                                                                                    <input type="radio" id="star5" class="form-check-input" style="margin-left: 12px" name="rating" value="5" <?php if ($thisUsrRating == '5') echo 'checked'; ?> /> <br>

                                                                                                </div>
                                                                                            </div>


                                                                                            <div class="form-group text-light ">
                                                                                                <label for="review"><b><i>Review</i></b></label>
                                                                                                <textarea class="form-control " id="review" name="review" required><?php echo "$thiUsrComment"; ?></textarea>
                                                                                            </div><br>
                                                                                            <div class="modal-footer">
                                                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                                                <button type="submit" name="submit" value="submit" class="btn btn-success">update</button>
                                                                                            </div>
                                                                                        </div>
                                                                                    </form>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                        <?php
                                                                    }
                                                                }
                                                                ?>

                                                                <p class="ps-5" style="font-size: 13px; margin-left: 10px; margin-top: 5px"><?php echo "$date"; ?></p>
                                                                <p class="ps-3"><?php echo "$comment"; ?></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <?php
                                                }
                                            }
                                        }
                                        ?>

                                        <?php
                                    } else {
                                        ?>
                                        <h4 class="text-center py-5">No Reviews</h4>
                                        <?php
                                    }
                                    ?>
                                </div>

                            </div>
                        </div>
                    </div>
                </section>
                <?php
            }
        }

        mysqli_close($link);

        include_once './footer.php';
        ?>


    </body>

</html>
