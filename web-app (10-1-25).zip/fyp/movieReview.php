<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<?php
session_start();
include_once './dbhConnect.php';

if (isset($_POST["submit"])) {
    if (isset($_SESSION["userId"])) {
        $rating = $_POST['rating'];
        $review = $_POST['review'];
        $userId = $_SESSION['userId'];
        $movieId = $_SESSION['movieId'];
        $currentDate = date('Y-m-d');

        if (!$link) {
            echo 'Connection error';
            exit();
        } else {
            $query = "SELECT movieId, userId FROM reviews WHERE movieId = '$movieId' AND userId = '$userId'";

            $result = mysqli_query($link, $query) or die(mysqli_error($link));

            if (mysqli_num_rows($result) > 0) {
                header('location:./movieInfo.php?id=' . $movieId . '&reviewFound');
            } else {
                $query1 = "INSERT INTO reviews (movieId, userId, review, rating, datePosted) VALUES ($movieId, $userId, '$review', $rating, CURDATE())";

                $result1 = mysqli_query($link, $query1);

                if (!$result1) {
                    header('location:./movieInfo.php?id=' . $movieId . '&error');
                } else {                  
                        header('location:./movieInfo.php?id=' . $movieId . '&Success');
                    }
                }
            }
        }
    }
?>
 

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        include_once './footer.php';
        ?>
    </body>
</html>
