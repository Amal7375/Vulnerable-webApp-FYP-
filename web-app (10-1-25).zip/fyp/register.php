<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    </head>
    <body class="bg-dark">
        <?php
        include_once './header.php';
        ?>
        <section class="bg-dark" >
            <div class="mask d-flex align-items-center h-100 gradient-custom-3">
                <div class="container h-100">
                    <div class="row d-flex justify-content-center align-items-center h-100">
                        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                            <div class="card mt-3 mb-5" style="border-radius: 15px;">
                                <div class="card-body p-5">
                                    <h2 class="text-uppercase text-center mb-5">Create an account</h2>
                                    
                                    <?php
                                        if (isset($_GET['error'])) {
                                            // Retrieve the error message from the query parameters
                                            $errorMessage = $_GET['error'];
                                            // Handle the error message as desired
                                            if ($errorMessage == "PasswordNotMatch") {
                                                echo '<div class="alert alert-danger"><b>Passwords do not match. Please try again.</b></div>';
                                            }
                                            else if($errorMessage == "usernameExist"){
                                                echo '<div class="alert alert-danger"><b>Username already exists.</b></div>';
                                            }
                                            else if($errorMessage == "emailExist"){
                                                echo '<div class="alert alert-danger"><b>Email already exists.</b></div>';
                                            }
                                            else {
                                                echo "An unknown error occurred.";
                                            }
                                        }
                                        ?>

                                    <form class="needs-validation" action="doRegister.php" method="post">
                                        <!-- Name -->
                                        <div class="form-floating was-validated">
                                            <input type="text" class="rounded-pill form-control form-control-lg ps-4 fst-italic" name="name" placeholder="name" required>                     
                                            <label class="ps-4" for="name">Your Name</label>  
                                        </div><br>
                                        <!-- ueser name -->
                                        <div class="form-floating was-validated">
                                            <input type="text" name="uname" class="form-control form-control-lg rounded-pill ps-4 fst-italic " placeholder="username" required/>
                                            <label class="ps-4" for="email">Username</label>
                                        </div><br>
                                        <!-- Email -->
                                        <div class="form-floating was-validated">
                                            <input type="email" name="email" class="form-control form-control-lg rounded-pill ps-4 fst-italic" placeholder="email@email.com" required/>
                                            <label class="ps-4" for="email">Enter Email</label>
                                        </div><br>
                                        <!-- Date of birth -->
                                        <div class="form-floating was-validated">
                                            <input type="date" name="dob" class="form-control form-control-lg rounded-pill ps-4 fst-italic" placeholder="zxc" required/>
                                            <label class="ps-4" for="email">Date of birth</label>
                                        </div><br>
                                        <!-- password -->
                                        <div class="form-floating was-validated">
                                            <input type="password" name="pwd" class="form-control form-control-lg rounded-pill ps-4 fst-italic" placeholder="password" required />
                                            <label class="ps-4" for="password">Password</label>
                                        </div><br>
                                        <!-- repeat password -->
                                        <div class="form-floating was-validated">
                                            <input type="password" name="repPwd" class="form-control form-control-lg rounded-pill ps-4 fst-italic" placeholder="repPassword" required />
                                            <label class="ps-4" for="password">Repeat your password</label>
                                        </div>
                                        <br><br>
                                        <div class="d-flex justify-content-center">
                                            <button type="submit" name="submit"
                                                    class="btn btn-success btn-block btn-lg gradient-custom-4 text-body">Register</button>
                                        </div>
                                        <!-- login -->
                                        <p class="text-center text-dark mt-5 mb-0">Have already an account? <a href="signin.php"
                                                                                                               class="fw-bold text-body"><u>Login here</u></a></p>                                                                     
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>



        <?php
        include_once './footer.php';
        ?>
    </body>
</html>
