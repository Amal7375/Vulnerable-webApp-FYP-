<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<?php
include_once './dbhConnect.php';
include_once './header.php';

if (!$link) {
    header('location:./home.php/NotAbleToConnect');
} else {
    $search = $_GET['q'];

    $sql = "SELECT * FROM movies WHERE movieTitle LIKE '%$search%' OR movieGenre LIKE '%$search%'";

    $result = mysqli_query($link, $sql);
    $num = mysqli_num_rows($result);
    if ($num > 0) {
        ?>
        <html>
            <head>
                <meta charset="UTF-8">
                <title></title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
            </head>

            <body class="bg-dark text-light">
                <!-- Header Section -->
                <div class="bg-dark text-white">
                    <div class="container">
                        <h1>Search Results</h1>
                        <hr>

                        <!-- Movie Results Section -->
                        <div class="bg-dark">
                            <div>
                                <h3>Movies</h3>
                            </div>
                            <?php
                            // Loop through each movie result
                            while ($row = mysqli_fetch_assoc($result)) {
                                ?>
                                <div class="">
                                    <a class="text-decoration-none" href="movieInfo.php?id=<?php echo $row['movieId']; ?>">
                                        <div class="d-flex flex-row mb-3 col-xm-3 col-md-12 card-body">
                                            <div>
                                                <!-- Display movie image -->
                                                <img src="images/<?php echo $row['picture']; ?>" style="width:100px; height:150px" alt="img">
                                            </div>
                                            <div class="col-12 p-3 text-light">
                                                <!-- Display movie details -->
                                                <h2><b><?php echo $row['movieTitle']; ?></b></h2>
                                                <h5><?php echo $row['runningTime']; ?></h5>
                                                <h5><?php echo $row['movieGenre']; ?></h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <?php
                            }
                            ?>
                        </div>

                        <!-- No Movies Found Section -->
                        <?php
                    } else {
                        ?>
                        <div>
                            <a class="text-decoration-none" href="home.php">
                                <h2>No Movies Found!</h2>
                            </a>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
        </div>

        <!-- Footer Section -->
        <?php include './footer.php'; ?>
    </body>
</html>
