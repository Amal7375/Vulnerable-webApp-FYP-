<?php
include_once './dbhConnect.php';

// Fetch all users
$query = "SELECT id, username, email FROM users";
$result = mysqli_query($link, $query);
?>

<h3>Delete User</h3>
<div class="table-responsive">
    <table class="table table-dark table-striped">
        <thead>
            <tr>
                <th>User ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['username']}</td>
                        <td>{$row['email']}</td>
                        <td>
                            <form method='post' action='admin.php'>
                                <input type='hidden' name='userId' value='{$row['id']}'>
                                <button type='submit' name='deleteUser' class='btn btn-danger'>Delete</button>
                            </form>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='4' class='text-center'>No users found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
