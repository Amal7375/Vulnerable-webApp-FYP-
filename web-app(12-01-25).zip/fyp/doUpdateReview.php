<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<?php
// Start the session
session_start();

// Include the database connection file
include_once './dbhConnect.php';

// Check if the form was submitted
if (isset($_POST["submit"])) {
    // Check if the user is logged in
    if (isset($_SESSION["userId"])) {
        // Extract data from the POST request
        $rating = $_POST['rating'];
        $review = $_POST['review'];
        $userId = $_SESSION['userId'];
        $movieId = $_SESSION['movieId'];

        // Check the database connection
        if (!$link) {
            echo 'Connection error';
            exit();
        } else {
            // Construct the SQL query for updating the review
            $query = "UPDATE reviews SET review = '$review', rating = '$rating' WHERE userId = '$userId' AND movieId = '$movieId'";

            // Execute the SQL query
            $result = mysqli_query($link, $query) or die(mysqli_error($link));

            // Redirect to movie info page with updated message
            header('location:./movieInfo.php?id=' . $movieId . '&updated');
        }
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
// put your code here
        ?>
    </body>
</html>
