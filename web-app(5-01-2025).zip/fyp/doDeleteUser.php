<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<?php
session_start();

if (null !== ($_POST["submit"])) {
    if (isset($_SESSION["userId"])) {

        include_once './dbhConnect.php';

        $userId = $_SESSION["userId"];
        $query = "DELETE FROM users WHERE userId = '$userId'";

        $result = mysqli_query($link, $query) or die(mysqli_error($link));

        if (!$result) {
            header('location:./userProfile.php?error');
        } else {
            include 'signout.php';
            header('location:./home.php');
        }
    }
}
?>
<html>

    <head>
        <meta charset = "UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
