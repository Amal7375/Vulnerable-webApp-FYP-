<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include_once './dbhConnect.php';

$name = $_POST['name'];
$uname = $_POST['uname'];
$email = $_POST['email'];
$dob = $_POST['dob'];
$pwd = $_POST['pwd'];
$rep = $_POST['repPwd'];

#Check connection
if (!$link) {
    echo 'Connection error';
    exit();
}

# Check User name used
$checkUsername = "SELECT * FROM users WHERE username = '$uname' ";

# Check User email used
$checkEmail = "SELECT * FROM users WHERE email = '$email' ";

#Check passwords
$passVer = FALSE;
if ($pwd != $rep) {
    header('location:./register.php?error=PasswordNotMatch ');
} else {
    $passVer = TRUE;
}

#execute Qurrey
$result1 = mysqli_query($link, $checkUsername);
$result2 = mysqli_query($link, $checkEmail);


if ($result1 or $result2) {
    if (mysqli_num_rows($result1) > 0) {                                            #check username
        header('location:./register.php?error=usernameExist');
        exit();
    } elseif (mysqli_num_rows($result2)) {                                       #check email
        header('location:./register.php?error=emailExist');
        exit();
    } else if ($pwd != $rep) {
        header('location:./register.php?error=PasswordNotMatch ');              #check password
    } else {
        $insertQurey = "INSERT INTO users(username,password,name,dob,email) VALUES ('$uname',('$pwd'),'$name','$dob','$email') ";

        $result = mysqli_query($link, $insertQurey);

        if (!$result) {
            header('location:./register.php?error=UnlnownError');
        } else {
            header('location:./signin.php?message=Success');
        }
    }
} else {
    echo "Error executing query: " . mysqli_error($link);
}


mysqli_close($link);
