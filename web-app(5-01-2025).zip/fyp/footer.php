<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body><br>
        <footer class="footer text-light ">
            <div class="container">
                <table class="row">
                    <div class="d-flex justify-content-center border-3">
                        <ul class="list-inline text-md-right">
                            <li class="list-inline-item"><a href="./home.php">Home</a></li>
                            <li class="list-inline-item"><a href="#">Back to Top</a></li>
                            <?php
                            if (isset($_SESSION['userId'])) {
                                ?>
                                <li class="list-inline-item"><a href="./signout.php">Logout</a></li>
                                <?php
                            } else {
                                ?>
                                <li class="list-inline-item"><a href="./signin.php">Login</a></li>
                                <?php
                            }
                            ?>
                        </ul>          
                    </div>
                    <div class="d-flex justify-content-center text-light">
                        <p>&copy; 2023 Movie Review. All rights reserved.</p>
                    </div>

                </table>
            </div>
        </footer>

    </body>
</html>
